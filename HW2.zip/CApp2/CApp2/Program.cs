﻿using System;

namespace CApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Половинкин Иван");

            A();
            B();
            C();
            D();

        }

        static void A()
        {
            Console.WriteLine("Я найду меньшее число из 3-ёх");

            Console.WriteLine("Введите первое число");
            int a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Введите второе число");
            int b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Введите третье число");
            int c = Convert.ToInt32(Console.ReadLine());

            int min;

            if (a < b && a < c)
            {
                min = a;
            }
            else if (b < a && b < c)
            {
                min = b;
            }
            else
            {
                min = c;

            }

            Console.WriteLine("Самое меньшее число из этих трёх это {0}", min);
        }

        static void B()
        {
            Console.Write("Введите число : ");
            int num = int.Parse(Console.ReadLine());
            int i = 0;
            while (num > 0)
            {
                i++;
                num /= 10;
            }
            Console.WriteLine("Количество цифр введенного числа : {0}", i);
            Console.ReadLine();
     
        }

        static void C()
        {
            Console.WriteLine("Вводите числа. Что-бы остановится введите 0");

            int sum = 0;
            while (true)
            {
                int i = Convert.ToInt16(Console.ReadLine());

                if (i != 0)
                {
                    if (i % 2 == 1)
                    { }
                    else
                        sum += i;
                }
                else
                {
                    break;
                }
            }
            Console.WriteLine("Cумма всех нечетных положительных чисел которые вы ввели: {0}", sum);
            Console.ReadKey();
        }

        static void D()
        {
            string login = "root";
            string password = "GeekBrains";

            int i = 0;
            while (i < 3)
            {
                Console.WriteLine("Введите логин");
                string userlogin = Console.ReadLine();

                Console.WriteLine("Введите пароль");
                string userpassword = Console.ReadLine();

                if (login == userlogin && password == userpassword)
                {
                    Console.WriteLine("Всё верно!");
                    break;
                }
                else
                {
                    Console.WriteLine("Не правильно!");
                    i++;
                    Console.WriteLine("У вас осталось {0}", 3 - i);

                }

            }
            if (i == 3)
            Console.WriteLine("Попытки закончились");

        }
    }
}
